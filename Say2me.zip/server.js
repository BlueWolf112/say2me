
var express = require('express')
  , path    = require('path')
  , app     = express.createServer()
